package com.ntu.cloudgui.app.model;

public enum Role {
    STANDARD, ADMIN
}
