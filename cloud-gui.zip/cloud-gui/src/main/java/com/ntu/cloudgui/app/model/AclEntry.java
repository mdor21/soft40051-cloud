package com.ntu.cloudgui.app.model;

public class AclEntry {
    private String fileId;
    private String username;
    private boolean canRead;
    private boolean canWrite;

    // getters/setters omitted for brevity
}
